<h2>
    <center>Selamat Datang</center>
</h2>
<center><img src="foto/logoo 2.png" alt="" class="img-responsive" height="100" width="100" /></center>
<hr color="black">
<center><img src="foto/makann.png" alt="" class="img-responsive" height="2000" width="500" /></center>

<link rel="stylesheet" href="css/style.css" type="text/css">